/*******************************************************************************
* File Name: Stepper2.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Stepper2_ALIASES_H) /* Pins Stepper2_ALIASES_H */
#define CY_PINS_Stepper2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Stepper2_0			(Stepper2__0__PC)
#define Stepper2_0_INTR	((uint16)((uint16)0x0001u << Stepper2__0__SHIFT))

#define Stepper2_1			(Stepper2__1__PC)
#define Stepper2_1_INTR	((uint16)((uint16)0x0001u << Stepper2__1__SHIFT))

#define Stepper2_2			(Stepper2__2__PC)
#define Stepper2_2_INTR	((uint16)((uint16)0x0001u << Stepper2__2__SHIFT))

#define Stepper2_3			(Stepper2__3__PC)
#define Stepper2_3_INTR	((uint16)((uint16)0x0001u << Stepper2__3__SHIFT))

#define Stepper2_INTR_ALL	 ((uint16)(Stepper2_0_INTR| Stepper2_1_INTR| Stepper2_2_INTR| Stepper2_3_INTR))

#endif /* End Pins Stepper2_ALIASES_H */


/* [] END OF FILE */
